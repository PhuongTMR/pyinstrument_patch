# Pyinstrument3.1.3 Patch

## Installation

    pip install pyinstrument_patch==0.0.1
